SURVIVOR CRAFTING ANYWHERE 1.0.0  (Ultimate ASI Loader plugin)
==============================================================

What it does
  Press F5 in any of your bases to open a rescued survivor's crafting menu:
  the Blacksmith, Carpenter, Alchemist, Hunter, Farmer, Collector, Bard,
  Fisher, Ancient Researcher and so on. You no longer need to travel to
  their base, or move them and give them a bed at every base.

  It is the game's own crafting menu. The tabs along the top become your
  survivors. Switch between them with Q / E or by clicking a tab. Esc closes the
  menu, and V still opens your own crafting as normal. The menu opens on the last
  survivor you used.

Inside or outside a base
  By default the menu only opens while you are inside a base (any base, not
  just the survivor's). To use it anywhere in the world, set
    allowOutsideBase=true
  in SurvivorCraftingAnywhere.ini. Outside a base, materials come from your
  backpack only.

How crafting works
  - The craft is made by the survivor at their own base, so the crafting
    stations they need (Forge, Smelter, ...) must be at THEIR base. The game
    shows which stations are needed and whether they are found.
  - Materials come from your backpack and from the chests of the base you are
    standing in, the same as at your own crafting.
  - Only survivors that are rescued and assigned to a base are listed.
    Assistants (Rochelle Anders, Aunt Braelyn, ...) are not listed separately:
    their recipes are under their survivor's tab. The Barber is not listed,
    because the Barber changes appearance and does not craft.

Requirements
  Ultimate ASI Loader by ThirteenAG (x64):
    https://github.com/ThirteenAG/Ultimate-ASI-Loader/releases
  Put its dll (dinput8.dll, or winmm.dll) next to enshrouded.exe. Many mods
  use it, so you may already have it: check for a "Scripts" folder next to
  enshrouded.exe with other .asi files in it.

INSTALL
  1. Extract the zip into the game folder, the one with enshrouded.exe, so
     that you have:
       ...\steamapps\common\Enshrouded\Scripts\SurvivorCraftingAnywhere.asi
       ...\steamapps\common\Enshrouded\Scripts\SurvivorCraftingAnywhere.ini
  2. Start the game and join or start your world.
  3. Go to one of your bases and press F5.

  Only you need it. The server or host does not need the mod (tested on a
  dedicated server).

CHANGE THE KEY
  Open Scripts\SurvivorCraftingAnywhere.ini with Notepad and change the line
    menuKey=F5
  for example to menuKey=F8, menuKey=Insert, menuKey=Num7 or menuKey=Ctrl+K.
  The full list of key names is in the file. Pick a key the game does not
  already use. Restart the game after a change.

CHECK IT WORKED
  If F5 does nothing, open survivor-crafting-anywhere.log in the game folder.
  The first lines should end with:
    ready (menu key F5, ...)
  "NOT fully ready" or "ERROR" lines mean a game update changed something and
  the mod needs updating. Survivors appear a few seconds after you join a world.
  Until then F5 does nothing and the log says so. Outside a base, F5 does
  nothing unless allowOutsideBase=true (the log says so too).

Settings (SurvivorCraftingAnywhere.ini)
  enabled            true/false
  menuKey            key that opens / closes the menu (default F5)
  allowOutsideBase   true = the menu also opens outside bases (default false)
  diagnostics        true = write survivors, tab switches and crafts to the log
  dumpKey            troubleshooting: key that writes the survivor list to the log

Compatibility
  Works alongside Creative Mode. Another mod that also changes the main menu's
  top tabs may conflict.

UNINSTALLING
  Delete these from the Scripts folder:
    SurvivorCraftingAnywhere.asi
    SurvivorCraftingAnywhere.ini
    SurvivorCraftingAnywhere-last.txt   (remembers the last survivor)
  The mod changes nothing in your world or character save.

Credits
  Ultimate ASI Loader by ThirteenAG - required, not included.
